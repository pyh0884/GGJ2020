Open GGJ file to play.
ps.Use Alt+F4 to exit the game,sorry about that.
This is the Windows Version of the game.